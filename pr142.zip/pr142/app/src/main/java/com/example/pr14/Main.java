package com.example.pr14;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Main extends AppCompatActivity implements View.OnClickListener {

    ImageView imageView6, imageView5, imageView3, imageView4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        imageView3=findViewById(R.id.imageView3);
        imageView3.setOnClickListener(this);

        imageView4=findViewById(R.id.imageView4);
        imageView4.setOnClickListener(this);

        imageView5=findViewById(R.id.imageView5);
        imageView5.setOnClickListener(this);

        imageView6=findViewById(R.id.imageView6);
        imageView6.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {


    }
    public void click3(View view){
        Intent intent = new Intent(this, recommendations.class);
        startActivity(intent);
    }
    public void click4(View view){
        Intent intent = new Intent(this, help.class);
        startActivity(intent);
    }
    public void click5(View view){
        Intent intent = new Intent(this, exercises.class);
        startActivity(intent);
    }
    public void click6(View view){
        Intent intent = new Intent(this, stati.class);
        startActivity(intent);
    }

}